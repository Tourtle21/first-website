"use strict"
document.addEventListener("DOMContentLoaded", function() {

var rotated = false;

document.getElementById('button').onclick = function() {
    var div = document.getElementsByClassName('arm1')
        
 
    div.style.transform       = 'rotate('+30+'deg)'; 


    
}


var box = document.getElementsByClassName("arm1")












});